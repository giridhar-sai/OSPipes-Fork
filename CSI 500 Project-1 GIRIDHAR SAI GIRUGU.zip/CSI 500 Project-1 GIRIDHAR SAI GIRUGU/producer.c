#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
#include <ctype.h>

#include "encDec.h"

void parentProcess(int giridharProdPipe[2], int giridharConsumerPiper[2])
{
    char *prodBuffer, *data, *fileName = NULL, *rawData = NULL, *convertBufferToFile = NULL, *dataFrameGiridhar;
    int pointerSize = 0, i, j, a = 0, b, fileSize = 0, ch = 0;
    frame frameData;
    FILE *fileConsData;
    int bytesRead = read(giridharProdPipe[0], &pointerSize, sizeof(int));
    (bytesRead == -1) ? (perror("Unable to read the pipe"), exit(0)) : 0;
    fileName = (char *)malloc(pointerSize + 1);
    if (bytesRead == 0)
    {
        perror("Ubable to allocate the size");
        exit(1);
    }
    int bytesRead1 = read(giridharProdPipe[0], fileName, pointerSize);
    (bytesRead1 == -1) ? (perror("Unable to read the pipe"), exit(0)) : 0;
    fileName[pointerSize] = '\0';
    fileConsData = openFile(fileName, "rw");
    (fileConsData == NULL) ? (perror("Unable to open the file : "), exit(1)) : 0;
    fileSize = 500;
    prodBuffer = (char *)malloc(fileSize);
    memset(prodBuffer, 0, fileSize);
    int bytesRead2 = fread(prodBuffer, 1, fileSize, fileConsData);
    (bytesRead2 == -1) ? (perror("Unable to read the pipe"), exit(0)) : 0;
    fclose(fileConsData);
    int q;

    char sz_per_byte = 0;

    rawData = (char *)malloc(fileSize);
    if (rawData == NULL)
    {
        perror("error occured while allocating data");
        exit(1);
    }
    int k = 0;
    while (k < 3)
    {
        rawData[k] = prodBuffer[k];
        rawData[k] = errorCheckDecode(rawData[k]);
        k++;
    }
    convertBufferToFile = (char *)malloc(rawData[2] + 1);
    if (convertBufferToFile == NULL)
    {
        perror("Error occured while allocating memory");
        exit(1);
    }
    convertBufferToFile[rawData[2]] = '\0';
    for (q = INFO; q < (INFO + rawData[2]); q++)
    {
        rawData[q] = prodBuffer[q];
        rawData[q] = errorCheckDecode(rawData[q]);
        if (islower(rawData[q]))
        {
            rawData[q] = (rawData[q] - ('a' - 'A'));
        }
        convertBufferToFile[ch] = rawData[q];
        ch++;
    }

    fileConsData = fopen("converted.outf", "w");
    fwrite(convertBufferToFile, sizeof(char), rawData[2], fileConsData);
    fclose(fileConsData);
    dataFrameGiridhar = (char *)malloc(fileSize);
    (dataFrameGiridhar == NULL) ? (perror("Erroroccured allocating the data "), exit(0)) : 0;
    i = 0;
    a = 0;
    while (i < (INFO + rawData[2]))
    {
        rawData[i] = changeToEncodedOddParity(rawData[i]);
        b = rawData[i];
        j = 0;
        while (j < 8)
        {
            int z = (b >> (3 + 4 - j));
            ((z & 1) == 1) ? (dataFrameGiridhar[a] = 1) : (dataFrameGiridhar[a] = 0);
            j++;
            a++;
        }
        i++;
    }

    fileConsData = openFile("converted.chck", "w");
    fwrite(rawData, sizeof(char), fileSize, fileConsData);
    fclose(fileConsData);
    free(dataFrameGiridhar);

    int fileNameSize = strlen("converted.chck");
    char *upperFileName = (char *)malloc(fileNameSize);
    strcpy(upperFileName, "converted.chck");
    int writtenBytes5 = write(giridharConsumerPiper[1], &fileNameSize, sizeof(int));
    (writtenBytes5 == -1) ? (perror("Error occured while"), exit(1)) : 0;

    int writtenBytes6 = write(giridharConsumerPiper[1], upperFileName, fileNameSize);
    (writtenBytes6 == -1) ? (perror("Error occured while"), exit(1)) : 0;
    char *args[] = {"./ParentProcess", NULL};
    execvp(args[0], args);
}