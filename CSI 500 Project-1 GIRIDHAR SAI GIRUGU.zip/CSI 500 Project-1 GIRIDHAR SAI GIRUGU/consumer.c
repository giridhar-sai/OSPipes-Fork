#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
#include <ctype.h>

#include "encDec.h"

void childProcess(int giridharProdPipe[2], int giridharConsumerPiper[2])
{
    FILE *filePointer, *giridharDataP, *encodedFile;
    char *pointBuffer = NULL, c;
    int encd, i, j = INFO, sizeOfEncodedFile = 0, fileSize, t_s, ch = 0, q, x;
    ch = 0;

    char *data = NULL, *dataFrame = NULL;
    char *rawData = NULL;
    char *encodeToUpperFile;

    filePointer = openFile("inputFile.inpf", "rw");
    fileSize = 500;

    pointBuffer = (char *)malloc(fileSize);
    if (pointBuffer == NULL)
    {
        perror("memory allocation failed");
        exit(1);
    }
    int total = INFO + fileSize;
    rawData = (char *)malloc(total);
    if (rawData == NULL)
    {

        free(pointBuffer);
        perror("memory allocation failed");
        exit(1);
    }
    data = (char *)malloc(total);
    if (data == NULL)
    {
        free(pointBuffer);
        free(rawData);
        perror("memory allocation failed");
        exit(1);
    }
    fread(pointBuffer, sizeof(char), fileSize, filePointer);

    int k = 0;
    while (k < 3)
    {
        if (k < 2)
        {
            rawData[k] = SYNCH_BIT;
        }
        else
        {
            rawData[k] = fileSize;
        }
        k++;
    }
    // for (i = 0; i < fileSize; i++)
    // {
    //     rawData[i];
    // }

    i = 0;
    while (i < fileSize)
    {
        rawData[j] = pointBuffer[i];
        i++;
        j++;
    }
    dataFrame = (char *)malloc((total * 8) + 1);
    if (dataFrame == NULL)
    {
        perror("Memory allocation is failed to the frame");
    }
    memset(dataFrame, 0, (total)*8);
    int point = 0;
    for (size_t i = 0; i < total; i++)
    {
        data[i] = changeToEncodedOddParity(rawData[i]);
        for (int j = 0; j < 8; j++)
        {
            dataFrame[point] = (data[i] >> (7 - j)) & 1;
            point++;
        }
        dataFrame[point] = '\0';
    }
    free(pointBuffer);
    giridharDataP = openFile("./giridharFrame.binf", "w");
    if (fwrite(data, 1, total, giridharDataP) == -1)
    {
        perror("Error while writing the file");
        exit(1);
    }
    fclose(giridharDataP);

    int frameLineLength = strlen("giridharFrame.binf");
    char *frameFileName = (char *)malloc(strlen("giridharFrame.binf"));
    const char *sourceFrameName = "giridharFrame.binf";
    strcpy(frameFileName, sourceFrameName);
    ssize_t bytesWritten = write(giridharProdPipe[1], &frameLineLength, sizeof(int));
    (bytesWritten == -1) ? (perror("Unable to write into producer"), exit(1))
                         : ((bytesWritten != sizeof(int)) ? (perror("Incomplete write into producer\n"), exit(1)) : 0);
    ssize_t bytesWritten1 = write(giridharProdPipe[1], frameFileName, frameLineLength);
    (bytesWritten == -1) ? (perror("Unable to write into producer"), exit(1))
                         : ((bytesWritten != sizeof(int)) ? (perror("Incomplete write into producer\n"), exit(1)) : 0);
    ssize_t bytesRead1 = read(giridharConsumerPiper[0], &sizeOfEncodedFile, sizeof(int));

    if (bytesRead1 == -1)
    {
        perror("Error occured while reading :");
        exit(1);
    }
    (bytesRead1 == -1) ? (perror("Unable to read the data from pipe\n: "), exit(1)) : 0;
    encodeToUpperFile = (char *)malloc(sizeOfEncodedFile + 1);

    ssize_t bytesRead = read(giridharConsumerPiper[0], encodeToUpperFile, sizeOfEncodedFile);

    (bytesRead == -1) ? (perror("Unable to read the data from pipe\n"), exit(-1))
                      : (encodeToUpperFile[bytesRead] = '\0', 0);
    encodedFile = openFile(encodeToUpperFile, "rw");
    sizeOfEncodedFile = 125;
    rawData = (char *)malloc(sizeOfEncodedFile);
    char *newPointBuffer;

    newPointBuffer = (char *)malloc(sizeOfEncodedFile);
    int bytesRead3 = fread(newPointBuffer, sizeof(char), sizeOfEncodedFile, encodedFile);
    (bytesRead3 == -1) ? (perror("file is not read ")) : 0;
    fclose(encodedFile);
    k = 0;
    while (k < 3)
    {
        rawData[k] = newPointBuffer[k];
        rawData[k] = errorCheckDecode(rawData[k]);
        k++;
    }

    char *sendBufferToFile;
    sendBufferToFile = (char *)malloc(rawData[2]);
    k = 0;
    for (k = INFO; k < (INFO + rawData[2]); k++)
    {
        sendBufferToFile[ch] = newPointBuffer[k];
        ch++;
    }
    encodedFile = fopen("output.done", "w");

    int byteswritten3 = fwrite(sendBufferToFile, sizeof(char), rawData[2], encodedFile);
    (byteswritten3 == -1) ? (perror("file is not written ")) : 0;
    fclose(encodedFile);
    char *args[] = {"./childProcess", NULL};
    execvp(args[0], args);
}