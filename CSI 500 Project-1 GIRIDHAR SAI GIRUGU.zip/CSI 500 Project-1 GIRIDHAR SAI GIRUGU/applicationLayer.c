#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
#include <ctype.h>

#include "encDec.h"

int main()
{
    // creating pipes for communication of producer and consumer
    int giridharProdPipe[2];      // reads in producer and writes on consumer
    int giridharConsumerPiper[2]; // reads in consumer and writes on producer
    int prodPipe, consPipe, pid, isChild, iter;
    // initialise the pipe for producer
    prodPipe = pipe(giridharProdPipe);
    // checking pipe creation
    checkPipeError(prodPipe);
    // initialise the pipe for producer
    consPipe = pipe(giridharConsumerPiper);
    // checking pipe creation
    checkPipeError(consPipe);
    // creating a fork to create a child process
    pid = createFork();
    // error checking for the fork whether it is created or not
    errorCheckFork(pid);
    // checking the pid to determin the process is whether child or parent
    isChild = checkProcess(pid);

    // entering the child process
    switch (!isChild)
    {
    case 0:
        // Code to execute when isChild is 0 (not a child process)

        childProcess(giridharProdPipe, giridharConsumerPiper);
        close(giridharProdPipe[0]);
        close(giridharConsumerPiper[1]);
        break;
    default:
        // Code to execute when isChild is not 0 (child process)

        parentProcess(giridharProdPipe, giridharConsumerPiper);
        close(giridharProdPipe[1]);
        close(giridharConsumerPiper[0]);
    }
    return 0;
}
