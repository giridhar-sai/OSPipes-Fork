#include "encDec.h"
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
#include <ctype.h>
#include "encDec.h"

int changeToEncodedOddParity(char p)
{

    int asciiValue = (int)p;
    int count = 0;
    int x = asciiValue;
    while (x > 0)
    {
        count += x & 1;
        x >>= 1;
    }

    if (count % 2 == 0)
    {
        asciiValue |= (1 << 7); // Adding odd parity bit
    }

    return asciiValue;
}

char errorCheckDecode(char c)
{

    int ch = 0, i, a;
    c &= 0xFF;
    a = c;
    int size = 8;
    while (a > 0)
    {
        if (a & 1)
        {
            ch++;
        }
        a >>= 1;
    }

    switch (isOdd(ch))
    {
    case 1:
        if ((a >> 7) & 1)
        {
            a &= 0x7F;
            return a;
        }
        break;
    case 0:
        switch ((a >> 7) & 1)
        {
        case 1:
            a &= 0x7F;
            return a;
            break;
        case 0:
            return -1;

        default:
            break;
        }

    default:
        break;
    }
    return c;
}

int isOdd(int a)
{
    return (a % 2);
}

void checkPipeError(int pipeId)
{
    if (pipeId == -1)
    {
        perror("Unable to open a pipe: ");
        exit(1);
    }
}
int createFork()
{
    return fork();
}
void errorCheckFork(int pid)
{
    if (pid == -1)
    {
        perror("Unable to create a fork");
        exit(1);
    }
}
int checkProcess(int pid)
{
    return (pid == 0);
}

FILE *openFile(const char *filename, const char *mode)
{
    FILE *filePointer = fopen(filename, mode);
    return filePointer;
}
