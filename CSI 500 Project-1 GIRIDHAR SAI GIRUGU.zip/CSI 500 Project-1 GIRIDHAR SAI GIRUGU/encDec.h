#ifndef ENCDEC_H
#define ENCDEC_H

#define MAX_LENGTH
#define INFO 3         // sync and lenght of characters in producer file
#define SYNCH_BIT 0x16 // SYNC bits. 2 ASCII 22s
#define bitOfdata ((INFO + f_s) * 8)
#define MAX 8

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
#include <ctype.h>

typedef struct data
{
    int l;
    char val;
} frame;

char errorCheckDecode(char candi);
int changeToEncodedOddParity(char);
int isOdd(int val);
void checkPipeError(int pipeId);
void errorCheckFork(int pid);
int createFork();
int checkProcess(int pid);
FILE *openFile(const char *filename, const char *mode);
void parentProcess(int giridharProdPipe[2], int giridharConsumerPiper[2]);
void childProcess(int giridharProdPipe[2], int giridharConsumerPiper[2]);

#endif
